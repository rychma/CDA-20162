<?php

namespace Doctrine\DBAL\Driver\OCI8;

final class Connection extends OCI8Connection
{
}
