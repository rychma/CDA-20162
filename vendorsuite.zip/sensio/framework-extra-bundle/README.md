SensioFrameworkExtraBundle
==========================

This bundle provides a way to configure your controllers with annotations.

Read about it on its [official homepage](http://symfony.com/doc/current/bundles/SensioFrameworkExtraBundle/index.html).
